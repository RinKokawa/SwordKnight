using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public int damage;
    public float time;
    // private Animator anim;
    new private PolygonCollider2D collider2D;
        // Start is called before the first frame update
    void Start()
    {
        collider2D = GetComponent<PolygonCollider2D>();
        collider2D.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        Attack();
    }

    void Attack(){
        if(Input.GetButtonDown("Attack")){
            // collider2D.enabled = true;
            StartCoroutine(creatHitBox());
        }
    }

    IEnumerator creatHitBox(){
        yield return new WaitForSeconds(time);
            collider2D.enabled = true;
            StartCoroutine(disableHitBox());
    }

    IEnumerator disableHitBox(){
        yield return new WaitForSeconds(time);
            collider2D.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D other) {
        if (other.gameObject.CompareTag("Enemy")){
            other.GetComponent<Enemy>().TakeDamage(damage);
        }
    }

}
