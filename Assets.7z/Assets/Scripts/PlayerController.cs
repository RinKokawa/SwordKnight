using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float runSpeed;
    public float jumpSpeed;

    private Rigidbody2D myRigidbody;
    private Animator myAnim; 
    private BoxCollider2D myFeet;
    private bool isGround;
    private bool canDoubleJump;
    // Start is called before the first frame update
    void Start()
    {
        myRigidbody = GetComponent<Rigidbody2D>();
        myAnim = GetComponent<Animator>();
        myFeet = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    //在每一帧都启动update里面的函数
    void Update()
    {
        Run();
        Flip();
        Jump();
        Attack();//由于已经在子物体里面定义攻击了，所以此处的攻击函数仅用于切换动画
        CheckGrounded();
        SwitchAnimation();
    }

    void CheckGrounded(){//检测角色是否接触地面
        isGround = myFeet.IsTouchingLayers(LayerMask.GetMask("Ground"));
        // Debug.Log(isGround);
    }

    void Flip(){
        bool playerHasXAxisSpeed = Mathf.Abs(myRigidbody.velocity.x) > Mathf.Epsilon;
        if(playerHasXAxisSpeed){
            //判断速度的方向，如果为向左，则将图像翻转
            if(myRigidbody.velocity.x > 0.1f){
                transform.localRotation = Quaternion.Euler( 0 , 0 , 0 );
            }
            if(myRigidbody.velocity.x < -0.1f){
                transform.localRotation = Quaternion.Euler( 0 , 180 , 0 );
            }
        }
    }
    //定义跑动的函数
    void Run()
    {
        //从Horizontal获得水平操控，移动人物
        float moveDir = Input.GetAxis("Horizontal");
        Vector2 playerVel = new Vector2(moveDir * runSpeed , myRigidbody.velocity.y);
        myRigidbody.velocity = playerVel;
        //判断人物是否具有速度
        bool playerHasXAxisSpeed = Mathf.Abs(myRigidbody.velocity.x) > Mathf.Epsilon;
        //控制动画状态机是否进入跑动动画
        myAnim.SetBool("Run" , playerHasXAxisSpeed);
    }

    //定义跳跃函数
    void Jump(){
    //监控跳跃键
        if(Input.GetButtonDown("Jump")){
            if (isGround){//检测地面，限制仅人物在地面时才可跳跃
                myAnim.SetBool("Jump",true);
                Vector2 jumpVel = new Vector2(0.0f , jumpSpeed);
                myRigidbody.velocity = Vector2.up * jumpVel;
                canDoubleJump = true;
            }
            else{
                if (canDoubleJump){
                Vector2 doubleJumpVel = new Vector2(0.0f , jumpSpeed);
                myRigidbody.velocity = Vector2.up * doubleJumpVel;
                canDoubleJump = false;
                }
            }
        }
    }

    void Attack(){//定义攻击
        if(Input.GetButtonDown("Attack")){//监听键盘是否按下攻击键位
            myAnim.SetTrigger("Attack");//切换动画状态机状态，切换动画
        }
    }


    void SwitchAnimation(){
        myAnim.SetBool("Idle", false);
        if(myAnim.GetBool("Jump")){
            if(myRigidbody.velocity.y < 0.0f){//检测掉落
                myAnim.SetBool("Jump",false);
                myAnim.SetBool("Fall",true);
            }
        }
        else if(isGround){//检测地面，将动画状态切换回呼吸
            myAnim.SetBool("Fall",false);
            myAnim.SetBool("Idle",true);
        }
    }
}
