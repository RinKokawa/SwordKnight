using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Enemy : MonoBehaviour
{
    public int health;//设定生命值
    public int damage;//设定伤害

    public float flashTime = 0.2f;//定义受击闪光时间

    private SpriteRenderer SR;
    private Color originalColor;

    private PlayerHealth playerHealth;//定义主角生命值变量

    public float deathtime;
    // Start is called before the first frame update
    public void Start()
    {
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
        SR = GetComponent<SpriteRenderer>();
        originalColor = SR.color;
    }

    // Update is called once per frame
    public void Update()
    {
        if (health <= 0){
            Destroy(gameObject);
        }
    }

    public void TakeDamage(int damage){
        health -= damage;
        FlashColor(flashTime);
    }

    void FlashColor(float time){
        SR.color = Color.red;
        Invoke("ResetColor", time);
    }

    void ResetColor(){
        SR.color = originalColor;
    }

    void OnTriggerEnter2D(Collider2D other){        
        if(other.gameObject.CompareTag("Player") && other.GetType().ToString() == "UnityEngine.CapsuleCollider2D"){
            if (playerHealth != null){                
                playerHealth.DamagePlayer(damage);
            }
        }
    }
}
