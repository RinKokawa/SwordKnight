using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatController : Enemy{
    private float speed = 2f;
    private float startWaitTime = 1f;
    private float waitTime = 0.5f;

    public Transform movePosition;//将要移动的位置
    public Transform leftDownPosition;//限定范围
    public Transform rightUpPosition;

    // Start is called before the first frame update
    public new void Start(){
        base.Start();
        waitTime = startWaitTime;
        movePosition.position = GetRandomPosition();
    }

    // Update is called once per frame
    public new void Update(){
        base.Update();
        transform.position = Vector2.MoveTowards(transform.position , movePosition.position , speed * Time.deltaTime);
        if (Vector2.Distance(transform.position , movePosition.position) < 0.1f){
            if (waitTime <= 0)
            {
                movePosition.position = GetRandomPosition();
                waitTime = startWaitTime;
            }
            else{
                waitTime -= Time.deltaTime;
            }
        }
        ConversionOrientation();
    }
    
    public void ConversionOrientation()//转换朝向
    {
        if (transform.position.x >= movePosition.position.x){
            transform.rotation = Quaternion.Euler(0f, 180f, 0f);
        }
        else{
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);
        }
    }

    Vector2 GetRandomPosition(){//生成随机位置
        Vector2 rndPosition = new Vector2(Random.Range(leftDownPosition.position.x , rightUpPosition.position.x),Random.Range(leftDownPosition.position.y , rightUpPosition.position.y));
        return rndPosition;
    }
}
